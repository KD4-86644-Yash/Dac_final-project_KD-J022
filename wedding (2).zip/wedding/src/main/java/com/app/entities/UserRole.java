package com.app.entities;

public enum UserRole {
	VENDOR, USER
}
