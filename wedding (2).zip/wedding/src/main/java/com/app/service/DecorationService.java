package com.app.service;

import java.util.List;

import com.app.dto.DecorationDto;
import com.app.dto.VenueDto;

//import antlr.collections.List;

public interface DecorationService {

//	List<DecorationDto> getAllVenue();
	List<DecorationDto> getAllDecoration();

}
