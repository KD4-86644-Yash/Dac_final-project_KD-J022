package com.app.service;

import com.app.dto.SigninRequest;
import com.app.dto.SigninResponse;
import com.app.entities.UserEntity;

public interface UserService {

	UserEntity addU(UserEntity u);
	//add signup method
}
