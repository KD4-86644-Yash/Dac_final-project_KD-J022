package com.app.entities;

public enum UserRole {
	VENDAR, USER
}
